import os
import google.generativeai as genai
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

# Bibliotecas para manejar imágenes
import base64
import io
import re 
from PIL import Image 
# --- FIN DE IMPORTS ---


# --- Configuración INICIAL ---
genai.configure(api_key="AIzaSyDF143rGvHJxpyJhqj0htLZmEUhf2M2IqA") # <-- Tu clave

model = genai.GenerativeModel('gemini-1.5-flash') 
app = Flask(__name__)
CORS(app) 
# --- FIN Configuración ---


# --- RUTA DE LA PÁGINA WEB ---
@app.route('/')
def index():
    return render_template('index.html')


# --- RUTA DE API 1: SLOGANS --- (Sin cambios)
@app.route('/generar-slogans', methods=['POST'])
def handle_slogans():
    try:
        data = request.json
        nombre_negocio = data.get('nombre')
        actividad_negocio = data.get('actividad')
        if not nombre_negocio or not actividad_negocio:
            return jsonify({"error": "Faltan datos (nombre o actividad)"}), 400
        prompt = f"""
        Actúa como un experto en branding y copywriting.
        Genera 5 slogans cortos, creativos y memorables para el siguiente negocio:
        - Nombre: "{nombre_negocio}" - Actividad: "{actividad_negocio}"
        Devuelve únicamente la lista de slogans, cada uno en una nueva línea. No agregues texto introductorio.
        """
        response = model.generate_content(prompt)
        slogans_texto = response.text.strip()
        lista_slogans = slogans_texto.split('\n')
        return jsonify({"slogans": lista_slogans})
    except Exception as e:
        print(f"Error en /generar-slogans: {e}")
        return jsonify({"error": str(e)}), 500


# --- RUTA DE API 2: GUIONES REELS --- (Sin cambios)
@app.route('/generar-guion', methods=['POST'])
def handle_guion():
    try:
        data = request.json
        tema_video = data.get('tema') 
        if not tema_video:
            return jsonify({"error": "Falta el tema del video"}), 400
        prompt = f"""
        Actúa como un creador de contenido experto en TikTok y Reels.
        Crea un guion para un video corto (15-20 segundos) sobre este tema: "{tema_video}".
        El guion debe estar dividido en 3 o 4 escenas cortas.
        Para cada escena, describe la acción visual, el texto que podría aparecer en pantalla y sugiere un tipo de audio o canción en tendencia.
        Formatea claramente cada escena.
        """
        response = model.generate_content(prompt)
        return jsonify({"guion": response.text.strip()})
    except Exception as e:
        print(f"Error en /generar-guion: {e}")
        return jsonify({"error": str(e)}), 500


# --- RUTA DE API 3: TRADUCTOR DE TONO --- 
@app.route('/traducir-tono', methods=['POST'])
def handle_tono():
    try:
        data = request.json
        texto_original = data.get('texto')
        tono_deseado = data.get('tono')
        if not texto_original or not tono_deseado:
            return jsonify({"error": "Falta el texto original o el tono"}), 400

        # --- CAMBIO EN EL PROMPT ---
        # Ahora pedimos 3 variaciones y un separador '---'
        prompt = f"""
        Actúa como un experto en comunicación y copywriting.
        Re-escribe el siguiente texto para que tenga un tono {tono_deseado}.
        Texto original:
        "{texto_original}"

        Genera 3 variaciones creativas distintas de esta re-escritura.
        Separa CADA variación únicamente con tres guiones (---).
        No agregues números o texto introductorio.
        """
        
        response = model.generate_content(prompt)
        texto_respuesta = response.text.strip()

        # --- CAMBIO EN EL PARSING ---
        # Dividimos la respuesta por el separador para crear una lista
        lista_variaciones = texto_respuesta.split('---')
        
        # Limpiamos espacios en blanco de cada item de la lista
        lista_limpia = [v.strip() for v in lista_variaciones if v.strip()] 

        # Devolvemos la LISTA (array) al frontend
        return jsonify({"variaciones": lista_limpia})

    except Exception as e:
        print(f"Error en /traducir-tono: {e}")
        return jsonify({"error": str(e)}), 500

# --- RUTA DE API 4: DESCRIPCIÓN DE PRODUCTO --- (Sin cambios)
@app.route('/describir-producto', methods=['POST'])
def handle_producto():
    try:
        data = request.json
        base64_string = data.get('imagen') 
        if not base64_string:
            return jsonify({"error": "No se recibió ninguna imagen"}), 400

        image_data = re.sub('^data:image/.+;base64,', '', base64_string)
        image_bytes = base64.b64decode(image_data)
        img = Image.open(io.BytesIO(image_bytes))

        prompt_texto = """
        Actúa como un copywriter experto en comercio electrónico.
        Observa la imagen de este producto.
        Escribe una descripción de producto de 2 o 3 frases que sea apetitosa, atractiva y vendedora.
        Enfócate en los detalles, texturas y posibles sensaciones que evoca.
        """
        response = model.generate_content([prompt_texto, img])
        return jsonify({"descripcion": response.text.strip()})
    except Exception as e:
        print(f"Error en /describir-producto: {e}")
        return jsonify({"error": str(e)}), 500



# --- RUTA DE API 5: ANALIZADOR DE SITUACIÓN (WOW) ---
@app.route('/analizar-situacion', methods=['POST'])
def handle_situacion():
    try:
        # 1. La lógica de recepción de imagen es IDÉNTICA a la función anterior
        data = request.json
        base64_string = data.get('imagen') 
        if not base64_string:
            return jsonify({"error": "No se recibió ninguna imagen"}), 400

        # 2. La lógica de decodificación es IDÉNTICA
        image_data = re.sub('^data:image/.+;base64,', '', base64_string)
        image_bytes = base64.b64decode(image_data)
        img = Image.open(io.BytesIO(image_bytes))

        # 3. Lo ÚNICO que cambia es el PROMPT que enviamos
        # Este prompt está basado en las fuentes 379-381
        prompt_texto = """
        Actúa como un experimentado gerente de restaurante/tienda y consultor de negocios.
        Observa esta imagen. Parece que el negocio está pasando por un momento de baja afluencia o tiene un problema (ej. local vacío, producto estancado).
        Basándote en lo que ves, genera 3 ideas de marketing o promociones accionables que el dueño podría implementar EN LA PRÓXIMA HORA para mejorar la situación.
        Sé creativo, directo y enfócate en resultados inmediatos.
        """

        # 4. La llamada a la API multimodal es IDÉNTICA
        response = model.generate_content([prompt_texto, img])

        # 5. Devolvemos las ideas generadas
        return jsonify({"ideas": response.text.strip()})

    except Exception as e:
        print(f"Error en /analizar-situacion: {e}")
        return jsonify({"error": str(e)}), 500
# --- FIN DE CÓDIGO NUEVO ---


# Esta línea inicia el servidor
if __name__ == '__main__':
    app.run(debug=True, port=5000)